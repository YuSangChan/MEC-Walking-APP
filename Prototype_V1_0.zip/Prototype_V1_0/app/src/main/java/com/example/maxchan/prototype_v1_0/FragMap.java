package com.example.maxchan.prototype_v1_0;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by MaxChan on 20/3/18.
 */

public class FragMap extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    SupportMapFragment mapFragment;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_map,container,false);

        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map__plaques1);
        if (mapFragment ==null)
        {
            FragmentManager fm = getFragmentManager();
            FragmentTransaction ft= fm.beginTransaction();
            mapFragment = SupportMapFragment.newInstance();
            ft.replace(R.id.map,mapFragment).commit();

        }
        mapFragment.getMapAsync(this);

        return v;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng Manly = new LatLng(-33.794012, 151.287366);
        mMap.setMinZoomPreference(18);
        mMap.setTrafficEnabled(false);
        mMap.addMarker(new MarkerOptions().position(Manly).title("Plaque 1: The Aboriginal Heritage of Manly"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Manly));
    }
}
