package com.example.maxchan.prototype_v1_0;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class PlaquesList extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{


    private DrawerLayout DrawerMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plaques_list);

        //setup drawer
        setupUI();
        //setup NavigationView
        setupNavigationView();
        //setup ViewPager
    }


    private void setupUI() {
        //setup drawer
        DrawerMain = (DrawerLayout) findViewById(R.id.drawer_layout_frag_plaqueslist);


    }


    private void setupNavigationView() {
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view_frag_plaqueslist);
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener()
                {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                        menuItem.setChecked(true);
                        switch(menuItem.getItemId())
                        {
                            case R.id.home:
                                DrawerMain.closeDrawers();
                                startActivity(new Intent(PlaquesList.this, MainActivity.class));
                                return true;
                            case R.id.track:
                                DrawerMain.closeDrawers();
                                startActivity(new Intent(PlaquesList.this, PlaquesList.class));
                                return true;
                            case R.id.map:
                                DrawerMain.closeDrawers();
                                startActivity(new Intent(PlaquesList.this, MapsActivity.class));
                            default:
                                return true;
                        }
                    }
                }
        );

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_activity_main);
        if (drawer.isDrawerOpen(GravityCompat.START))
            drawer.closeDrawer(GravityCompat.START);
        else
            super.onBackPressed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.nav_drawer,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.action_settings){
            return true;
        }
        if (id == R.id.home)
        {
            DrawerMain.openDrawer(GravityCompat.START);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem menuItem) {
        return false;
    }

    //onclick cardView1
    public void Plaques1pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques2pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques2.class));
    }
    //onclick cardView1
    public void Plaques3pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques4pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques5pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques6pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques7pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques8pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques9pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques10pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques11pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques12pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques13pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques14pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques15pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }
    //onclick cardView1
    public void Plaques16pl(View v) {
        startActivity(new Intent(PlaquesList.this, Plaques1.class));
    }


}
