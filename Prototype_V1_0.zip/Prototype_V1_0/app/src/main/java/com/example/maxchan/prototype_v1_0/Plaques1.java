package com.example.maxchan.prototype_v1_0;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
public class Plaques1 extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private ActionBarDrawerToggle DrawerMainToggle;
    private DrawerLayout DrawerMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plaques1);

        //setup drawer
        setupUI();
        //setup NavigationView
        setupNavigationView();
        //setup ViewPager
        setupViewPager();
    }

    private void setupUI() {
        //setup drawer
        DrawerMain = (DrawerLayout) findViewById(R.id.drawer_layout_plaques1);
        //setup toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_plaques1);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //setup Toggler
        DrawerMainToggle = new ActionBarDrawerToggle(Plaques1.this,DrawerMain,toolbar,R.string.app_name,R.string.app_name)
        {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };
        DrawerMain.setDrawerListener(DrawerMainToggle);
        DrawerMainToggle.syncState();
    }

    private void setupNavigationView() {
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view_plaques1);
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener()
                {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                        menuItem.setChecked(true);
                        switch(menuItem.getItemId())
                        {
                            case R.id.home:
                                startActivity(new Intent(Plaques1.this, MainActivity.class));
                                DrawerMain.closeDrawers();
                                return true;
                            case R.id.track:
                                DrawerMain.closeDrawers();
                                startActivity(new Intent(Plaques1.this, PlaquesList.class));
                                return true;
                            case R.id.map:
                                DrawerMain.closeDrawers();
                                startActivity(new Intent(Plaques1.this, MapsActivity.class));
                            default:
                                return true;
                        }
                    }
                }
        );
    }




    private void setupViewPager() {
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager_plaques1);
        if (viewPager != null) {
            setupViewPager(viewPager);
        }
        //setup TabLayout
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs_plaques1);
        tabLayout.setupWithViewPager(viewPager);
    }


    private void setupViewPager(ViewPager viewPager) {
        Adapter adapter = new Adapter(getSupportFragmentManager());
        adapter.addFragment(new FragContent(), "Content");
        adapter.addFragment(new FragMap(), "Map");
        adapter.addFragment(new FragOthers(), "Others");
        viewPager.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_plaques1);
        if (drawer.isDrawerOpen(GravityCompat.START))
            drawer.closeDrawer(GravityCompat.START);
        else
            super.onBackPressed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.nav_drawer,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.action_settings){
            return true;
        }
        if (id == R.id.home)
        {
            DrawerMain.openDrawer(GravityCompat.START);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem menuItem) {
        return false;
    }
}
