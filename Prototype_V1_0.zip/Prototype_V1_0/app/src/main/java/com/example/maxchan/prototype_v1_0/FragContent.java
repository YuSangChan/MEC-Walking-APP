package com.example.maxchan.prototype_v1_0;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by MaxChan on 20/3/18.
 */

public class FragContent  extends Fragment{

    int id;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_content,container,false);
        return v;
    }

    public void setId(int id) {
        this.id = id;
    }
}
